# ✏️ وكيل الكابشنات — علا

كابشنات إعلانية للسادس الإعدادي | لهجة عراقية أصيلة | منطق 50/50

---

## 🚀 خطوات النشر (بدون خبرة تقنية)

### الخطوة ١ — احصل على مفتاح Claude API
1. افتح [console.anthropic.com](https://console.anthropic.com)
2. سجّل حساب جديد (بريد + باسورد)
3. أضف بيانات دفع (بطاقة) — **لا يوجد اشتراك شهري، تدفع بس على الاستخدام، سنتات لكل دفعة كابشنات**
4. من القائمة الجانبية → **API Keys** → **Create Key**
5. انسخ المفتاح (يبدأ بـ `sk-ant-...`) واحفظه بمكان آمن

---

### الخطوة ٢ — احصل على حساب GitHub
1. افتح [github.com](https://github.com) وسجّل حساب مجاني
2. من الصفحة الرئيسية → **New Repository**
3. اسم الـrepo: `ula-caption-agent`
4. اختر **Private** ← **Create Repository**

---

### الخطوة ٣ — ارفع ملفات المشروع
في الـrepo الجديد:
1. اضغط **Add file** → **Upload files**
2. ارفع هذه الملفات:
   - `app.py`
   - `agent.py`
   - `config.py`
   - `requirements.txt`
3. اصنع مجلد `data/` وحط فيه ملف تحليل المنافسين واسمّه:
   `competitor_analysis.py`
4. اضغط **Commit changes**

---

### الخطوة ٤ — انشر على Streamlit Cloud (مجاناً)
1. افتح [share.streamlit.io](https://share.streamlit.io)
2. سجّل دخول بحساب GitHub
3. اضغط **New app**
4. اختر الـrepository: `ula-caption-agent`
5. الـMain file path: `app.py`
6. اضغط **Deploy!**

---

### الخطوة ٥ — أضف مفتاح API
بعد ما يبدأ النشر:
1. من لوحة Streamlit → **Settings** (أيقونة ⚙️)
2. → **Secrets**
3. الصق هذا واستبدل المفتاح:
   ```
   ANTHROPIC_API_KEY = "sk-ant-api03-مفتاحك-هنا"
   ```
4. اضغط **Save** — التطبيق يعيد التشغيل تلقائياً

---

### ✅ خلاص — تطبيقك جاهز على رابط مثل:
```
https://ula-caption-agent-xxxx.streamlit.app
```

---

## 📁 هيكل الملفات

```
ula-caption-agent/
├── app.py                    ← الواجهة الرئيسية
├── agent.py                  ← منطق الوكيل + استدعاء API
├── config.py                 ← إعدادات الـskill (صوت علا، الخريطة، اللهجة)
├── requirements.txt          ← المكتبات المطلوبة
├── data/
│   └── competitor_analysis.py  ← ملف تحليل المنافسين (مخرجات وكيل التحليل)
└── .streamlit/
    └── secrets.toml          ← مفتاح API (لا ترفعه على GitHub!)
```

---

## ⚙️ تغيير الموديل

في `config.py`:
```python
MODEL = "claude-sonnet-4-6"   # غيّره حسب ما تريد
```
تحقق من الموديلات المتاحة على: [console.anthropic.com/settings/models](https://console.anthropic.com/settings/models)

---

## 💰 التكلفة التقريبية
- كل دفعة 4 كابشنات: ~$0.01–0.03 (سنتات)
- الاستضافة على Streamlit Cloud: **مجانية**
- لا اشتراك شهري — تدفع بس على ما تستخدم
